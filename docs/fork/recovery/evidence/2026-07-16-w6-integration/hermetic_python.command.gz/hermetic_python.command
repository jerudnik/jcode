/Library/Developer/CommandLineTools/usr/bin/python3 tests/test_r10_release_acquisition.py 
