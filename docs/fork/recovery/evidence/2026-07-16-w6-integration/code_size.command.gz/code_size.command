/Library/Developer/CommandLineTools/usr/bin/python3 scripts/check_code_size_budget.py 
