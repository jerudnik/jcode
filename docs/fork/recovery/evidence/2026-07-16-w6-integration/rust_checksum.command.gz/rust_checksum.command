cargo test -p jcode-app-core verify_asset_checksum -- --nocapture 
