/Library/Developer/CommandLineTools/usr/bin/python3 scripts/check_dependency_boundaries.py 
