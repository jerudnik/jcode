/Library/Developer/CommandLineTools/usr/bin/python3 scripts/check_wildcard_reexport_budget.py 
