bash -c cd\ docs/fork/recovery/evidence/2026-07-16-w6-r10\ \&\&\ shasum\ -a\ 256\ -c\ SHA256SUMS 
