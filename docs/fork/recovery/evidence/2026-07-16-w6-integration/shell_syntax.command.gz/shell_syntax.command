bash -n scripts/install.sh scripts/install_release.sh scripts/quick-release.sh 
