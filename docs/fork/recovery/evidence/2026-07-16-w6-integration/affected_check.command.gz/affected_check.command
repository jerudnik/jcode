cargo check -p jcode-app-core 
