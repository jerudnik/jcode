scripts/dev_cargo.sh check -p jcode-app-core -p jcode-base -p jcode-storage 
