python3 scripts/check_panic_budget.py 
