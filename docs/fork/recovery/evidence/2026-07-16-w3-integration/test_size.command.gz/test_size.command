python3 scripts/check_test_size_budget.py 
