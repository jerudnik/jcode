python3 -m unittest discover -s tests -p test_rust_production_filter.py 
